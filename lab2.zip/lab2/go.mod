module lab2

go 1.25.5
